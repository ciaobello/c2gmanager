﻿<?php

$arrImportedFiles = scan(TL_ROOT.'/tl_files/import');

	$arrOutput = array();
	
foreach ($arrImportedFiles as $importfile )
{
	if (copy(TL_ROOT.'/tl_files/import/'.$importfile,TL_ROOT.'/backups/'.$importfile))
	{
		$arrOutput[] = sprintf("File <i>%s</i> imported with success",$importfile);
		unlink(TL_ROOT.'/tl_files/import/'.$importfile);
	}
	else
	{
	
		$arrOutput[] = sprintf("File <i>%s</i> could NOT be imorted",$importfile);
	}
	
	
	
}

	$pathBackups = $this->replaceInsertTags('{{link_url::backups}}');

$arrOutput[] = sprintf('<a href="%s" title="Hosts">Back to the overview of Backups</a>',$pathBackups);
echo implode("<br>",$arrOutput);
?>
